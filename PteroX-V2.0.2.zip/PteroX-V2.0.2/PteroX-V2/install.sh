#!/usr/bin/env bash
set -euo pipefail

PANEL="/var/www/pterodactyl"
BACKUP="$PANEL/storage/pterox-backups"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "======================================"
echo "        PteroX V2 Installer"
echo "======================================"
echo

if [ ! -d "$PANEL" ]; then
    echo "❌ Pterodactyl installation not found:"
    echo "   $PANEL"
    exit 1
fi

cd "$PANEL"

VERSION="$(php artisan p:info 2>/dev/null | awk '/Panel Version/ {print $NF}')"

echo "Detected Pterodactyl: ${VERSION:-unknown}"

case "$VERSION" in
    1.14.*)
        echo "✅ Compatible Pterodactyl 1.14.x detected."
        ;;
    *)
        echo "❌ PteroX V2 requires Pterodactyl 1.14.x."
        echo "   Detected: ${VERSION:-unknown}"
        exit 1
        ;;
esac

echo
echo "======================================"
echo "          PteroX V2 Installation"
echo "======================================"
echo
echo "This will:"
echo "  • Backup files that PteroX will modify"
echo "  • Install PteroX V2"
echo "  • Install required frontend dependencies"
echo "  • Build the frontend"
echo "  • Clear Laravel caches"
echo
echo "Pterodactyl:"
echo "  $PANEL"
echo
echo

read -r -p "Continue with PteroX V2 installation? [y/N]: " CONFIRM

case "$CONFIRM" in
    y|Y|yes|YES|Yes)
        ;;
    *)
        echo
        echo "Installation cancelled."
        exit 0
        ;;
esac

echo
echo "Creating backup..."

BACKUP_DIR="$BACKUP/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

while IFS= read -r file; do
    src="$SCRIPT_DIR/files/$file"
    dst="$PANEL/$file"

    mkdir -p "$BACKUP_DIR/$(dirname "$file")"
    mkdir -p "$(dirname "$dst")"

    if [ -f "$dst" ]; then
        cp -a "$dst" "$BACKUP_DIR/$file"
    fi
done < <(cd "$SCRIPT_DIR/files" && find . -type f -printf '%P\n')

echo "✅ Backup created:"
echo "   $BACKUP_DIR"

echo
echo "Installing PteroX V2..."

while IFS= read -r file; do
    src="$SCRIPT_DIR/files/$file"
    dst="$PANEL/$file"

    mkdir -p "$(dirname "$dst")"
    cp -a "$src" "$dst"

    echo "  ✓ $file"
done < <(cd "$SCRIPT_DIR/files" && find . -type f -printf '%P\n')

echo
echo "Checking Yarn..."

if ! command -v yarn >/dev/null 2>&1; then
    echo "❌ Yarn is not installed."
    exit 1
fi

echo "✅ Yarn detected: $(yarn --version)"

cd "$PANEL"

echo
echo "Installing PteroX frontend dependencies..."

yarn add @fontsource/poppins @fortawesome/free-brands-svg-icons

echo
echo "Building frontend..."

yarn build:production

echo
echo "Clearing Laravel cache..."

php artisan optimize:clear

echo
echo "======================================"
echo "       PteroX V2 installed!"
echo "======================================"
echo
echo "Backup:"
echo "  $BACKUP_DIR"
echo
echo "Refresh the panel with:"
echo "  Ctrl+Shift+R"
echo
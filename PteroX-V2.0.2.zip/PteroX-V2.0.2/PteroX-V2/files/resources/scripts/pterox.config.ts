/**
 * PteroX V2 Branding Configuration
 *
 * Customers can edit this file to customize their PteroX branding.
 */

export const PTEROX_CONFIG = {
    name: 'pterox',
    email: 'pterox@webpool.tech',


    // Main panel sidebar logo
    sidebarLogo: '/images/pterox-sidebar-logo.webp',

    // Main panel header logo
    headerLogo: '/images/pterox-header-logo.webp',

    // Login page main logo
    loginLogo: '/images/pterox-login-logo.webp',

    // Login page header logo
    loginHeaderLogo: '/images/pterox-login-header-logo.webp',
};

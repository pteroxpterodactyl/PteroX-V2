# PteroX V2

PteroX V2 is a modern frontend theme for Pterodactyl Panel featuring a redesigned dark interface, custom navigation, server management UI, and configurable branding.

## Compatibility

- **Pterodactyl Panel:** 1.14.x
- **Recommended version:** 1.14.1
- **Node.js:** Required
- **Yarn:** Required
- **PHP:** Required
- **Composer:** Required
- **curl:** Required
- **Python 3:** Required by the installer

PteroX V2 is designed for **Pterodactyl 1.14.x**. Other versions are not guaranteed to work.

## License

PteroX V2 requires a valid license key. The installer validates and activates the license before installation.

Each license can only be activated once. Do not publicly share license keys or commit them to public repositories.

## Installation

### 1. Upload PteroX V2

Upload the **complete `PteroX-V2` folder** to your server, for example:

```text
/tmp/PteroX-V2/
```

Do **not** manually copy the contents of `files/`. The installer does this automatically.

### 2. Run the installer

```bash
cd /tmp/PteroX-V2
chmod +x install.sh
sudo ./install.sh
```

Enter your PteroX V2 license key when prompted.

The installer automatically:

1. Checks Pterodactyl 1.14.x compatibility.
2. Validates and activates your license.
3. Generates a unique installation ID.
4. Creates a timestamped backup.
5. Installs the PteroX files.
6. Builds the frontend.
7. Clears Laravel caches.

If license validation fails, installation is cancelled.

After installation, hard-refresh the panel with **Ctrl + Shift + R**.

## Automatic Backups

Backups are stored in:

```text
/var/www/pterodactyl/storage/pterox-backups/
```

Keep your backup until you have confirmed the installation works correctly.

# Branding & Customization

Normal branding changes are controlled by:

```text
/var/www/pterodactyl/resources/scripts/pterox.config.ts
```

Edit it with:

```bash
nano /var/www/pterodactyl/resources/scripts/pterox.config.ts
```

Default configuration:

```ts
export const PTEROX_CONFIG = {
    name: 'pterox',
    email: 'pterox@webpool.tech',
    logo: '/images/pterox-logo.webp',
    headerName: 'PteroX',
};
```

### Sidebar Name

Change:

```ts
name: 'pterox',
```

to your brand, for example:

```ts
name: 'WebPool',
```

### Sidebar Email

Change:

```ts
email: 'pterox@webpool.tech',
```

for example:

```ts
email: 'support@webpool.tech',
```

### Logo

Upload your logo to:

```text
/var/www/pterodactyl/public/images/
```

For example:

```text
/var/www/pterodactyl/public/images/webpool-logo.webp
```

Then change:

```ts
logo: '/images/webpool-logo.webp',
```

The configured logo is used by supported PteroX branding locations, including the sidebar and login page.

### Header / Login Branding

Change:

```ts
headerName: 'PteroX',
```

for example:

```ts
headerName: 'WebPool',
```

The `headerName` and `logo` values control the corresponding login branding.

### Complete Example

```ts
export const PTEROX_CONFIG = {
    name: 'WebPool',
    email: 'support@webpool.tech',
    logo: '/images/webpool-logo.webp',
    headerName: 'WebPool',
};
```

## Rebuild After Branding Changes

After changing `pterox.config.ts`:

```bash
cd /var/www/pterodactyl
yarn build:production
php artisan optimize:clear
```

Then hard-refresh with **Ctrl + Shift + R**.

Normal branding changes should be made through `pterox.config.ts`; you normally do not need to edit the component files directly.

# Uninstallation

Enter the PteroX package directory:

```bash
cd /tmp/PteroX-V2
```

Run:

```bash
chmod +x uninstall.sh
sudo ./uninstall.sh
```

The uninstaller restores the most recent PteroX backup.

Afterward:

```bash
cd /var/www/pterodactyl
php artisan optimize:clear
```

Then hard-refresh the panel.

# Troubleshooting

### Invalid License

If you receive `Invalid license key.`, verify the key and try again.

### License Already Activated

If you receive `License has already been activated.`, the license has already been used. Contact PteroX support if this is unexpected.

### License API Unavailable

If the installer cannot contact the license API, verify server internet access, DNS, and HTTPS connectivity.

### Unsupported Pterodactyl Version

PteroX V2 requires Pterodactyl 1.14.x. Do not bypass the version check.

### Frontend Build Problems

Check:

```bash
node -v
npm -v
yarn -v
php -v
```

Then:

```bash
cd /var/www/pterodactyl
yarn build:production
php artisan optimize:clear
```

### Branding Changes Not Showing

Run:

```bash
cd /var/www/pterodactyl
php artisan optimize:clear
yarn build:production
```

Then hard-refresh the browser.

# Important Notes

- PteroX V2 is designed for Pterodactyl 1.14.x.
- Keep your PteroX backups.
- Never publicly share license keys.
- Do not include license keys in the PteroX distribution.
- Each license is intended for one activation.
- The installer requires access to the PteroX License API.
- Future PteroX updates may overwrite custom frontend modifications.
- PteroX V2 does not install Pterodactyl, Node.js, Yarn, PHP, or Composer for you.

# Support

Before requesting support, check your Pterodactyl, Node.js, Yarn, and PHP versions and review the troubleshooting section.

When contacting support, provide:

- Pterodactyl version
- PteroX V2 version
- Node.js version
- Yarn version
- PHP version
- Exact error message

**Never send your license key publicly.**

---

# PteroX V2

**Modern Pterodactyl. Built for a cleaner experience.**

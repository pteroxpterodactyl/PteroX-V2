#!/usr/bin/env bash
set -euo pipefail

PANEL="/var/www/pterodactyl"
BACKUP="$PANEL/storage/pterox-backups"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LICENSE_API="https://license.joinmccloud.fun/activate"

echo "======================================"
echo "        PteroX V2 Installer"
echo "======================================"
echo

if [ ! -d "$PANEL" ]; then
    echo "❌ Pterodactyl installation not found:"
    echo "   $PANEL"
    exit 1
fi

cd "$PANEL"

VERSION="$(php artisan p:info 2>/dev/null | awk '/Panel Version/ {print $NF}')"

echo "Detected Pterodactyl: ${VERSION:-unknown}"

case "$VERSION" in
    1.14.*)
        echo "✅ Compatible Pterodactyl 1.14.x detected."
        ;;
    *)
        echo "❌ PteroX V2 requires Pterodactyl 1.14.x."
        echo "   Detected: ${VERSION:-unknown}"
        exit 1
        ;;
esac

echo
echo "======================================"
echo "       PteroX V2 License Check"
echo "======================================"
echo

read -r -p "Enter your PteroX V2 license key: " LICENSE_KEY
LICENSE_KEY="$(echo "$LICENSE_KEY" | xargs)"

if [ -z "$LICENSE_KEY" ]; then
    echo
    echo "❌ No license key entered."
    echo "Installation cancelled."
    exit 1
fi

INSTALLATION_ID="PTEROX-$(hostname)-$(date +%s)-$(od -An -N8 -tx1 /dev/urandom | tr -d ' \n')"

echo
echo "Checking license..."

if ! command -v curl >/dev/null 2>&1; then
    echo "❌ curl is not installed."
    echo "Installation cancelled."
    exit 1
fi

RESPONSE="$(curl -fsS \
    --connect-timeout 10 \
    --max-time 20 \
    -X POST \
    -H "Content-Type: application/json" \
    -d "{\"key\":\"$LICENSE_KEY\",\"installation_id\":\"$INSTALLATION_ID\"}" \
    "$LICENSE_API" 2>/dev/null || true)"

if [ -z "$RESPONSE" ]; then
    echo "❌ Could not contact the PteroX License API."
    echo "Installation cancelled."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "❌ Python 3 is required by the PteroX installer."
    echo "Installation cancelled."
    exit 1
fi

LICENSE_VALID="$(printf '%s' "$RESPONSE" | python3 -c '
import json
import sys
try:
    data = json.load(sys.stdin)
    print("true" if data.get("success") and data.get("valid") else "false")
except Exception:
    print("false")
' 2>/dev/null || echo "false")"

LICENSE_ERROR="$(printf '%s' "$RESPONSE" | python3 -c '
import json
import sys
try:
    data = json.load(sys.stdin)
    print(data.get("error", "License validation failed."))
except Exception:
    print("License validation failed.")
' 2>/dev/null || echo "License validation failed.")"

if [ "$LICENSE_VALID" != "true" ]; then
    echo
    echo "❌ License validation failed."
    echo
    echo "   $LICENSE_ERROR"
    echo
    echo "Installation cancelled."
    exit 1
fi

echo
echo "✅ License valid."
echo "✅ License activated."
echo "✅ PteroX V2 license accepted."

echo
echo "Creating backup..."

BACKUP_DIR="$BACKUP/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

while IFS= read -r file; do
    src="$SCRIPT_DIR/files/$file"
    dst="$PANEL/$file"

    mkdir -p "$BACKUP_DIR/$(dirname "$file")"
    mkdir -p "$(dirname "$dst")"

    if [ -f "$dst" ]; then
        cp -a "$dst" "$BACKUP_DIR/$file"
    fi
done < <(cd "$SCRIPT_DIR/files" && find . -type f -printf '%P\n')

echo "✅ Backup created:"
echo "   $BACKUP_DIR"

echo
echo "Installing PteroX V2..."

while IFS= read -r file; do
    src="$SCRIPT_DIR/files/$file"
    dst="$PANEL/$file"

    mkdir -p "$(dirname "$dst")"
    cp -a "$src" "$dst"

    echo "  ✓ $file"
done < <(cd "$SCRIPT_DIR/files" && find . -type f -printf '%P\n')

echo
echo "Building frontend..."

cd "$PANEL"

if ! command -v yarn >/dev/null 2>&1; then
    echo "❌ Yarn is not installed."
    exit 1
fi

yarn build:production

echo
echo "Clearing Laravel cache..."

php artisan optimize:clear

echo
echo "======================================"
echo "       PteroX V2 installed!"
echo "======================================"
echo
echo "Backup:"
echo "  $BACKUP_DIR"
echo
echo "Press Ctrl+Shift+R in your browser."

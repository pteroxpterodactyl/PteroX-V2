#!/usr/bin/env bash
set -euo pipefail

PANEL="/var/www/pterodactyl"
BACKUP_ROOT="$PANEL/storage/pterox-backups"

echo "======================================"
echo "        PteroX V2 Uninstaller"
echo "======================================"
echo

if [ ! -d "$BACKUP_ROOT" ]; then
    echo "❌ No PteroX backups found."
    exit 1
fi

LATEST="$(find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d | sort | tail -n 1)"

if [ -z "$LATEST" ] || [ ! -d "$LATEST" ]; then
    echo "❌ Could not find a PteroX backup."
    exit 1
fi

echo "Using backup:"
echo "  $LATEST"
echo

read -r -p "Restore this backup? [y/N] " answer

if [[ ! "$answer" =~ ^[Yy]$ ]]; then
    echo "Cancelled."
    exit 0
fi

cd "$PANEL"

while IFS= read -r file; do
    src="$LATEST/$file"
    dst="$PANEL/$file"

    if [ -f "$src" ]; then
        mkdir -p "$(dirname "$dst")"
        cp -a "$src" "$dst"
        echo "  ✓ Restored $file"
    fi
done < <(cd "$LATEST" && find . -type f -printf '%P\n')

php artisan optimize:clear

echo
echo "======================================"
echo "       PteroX V2 restored!"
echo "======================================"
echo
echo "Rebuild the frontend if necessary:"
echo "  yarn build:production"

import tw from 'twin.macro';
import { createGlobalStyle } from 'styled-components/macro';
// @ts-expect-error untyped font file
import font from '@fontsource/poppins/files/poppins-latin-400-normal.woff2';

export default createGlobalStyle`
    /* PteroX V2 visual polish */
    a {
        transition: color 150ms ease, background-color 150ms ease, border-color 150ms ease;
    }

    ::selection {
        background: #ff5500;
        color: #ffffff;
    }

    input, textarea, select {
        font-family: 'Poppins', sans-serif;
    }

    @font-face {
        font-family: 'Poppins';
        font-style: normal;
        font-display: swap;
        font-weight: 400;
        src: url(${font}) format('woff2-variations');
    }

    :root {
        color-scheme: dark;
    }

    html,
    body,
    #app {
        min-height: 100%;
    }

    body {
        font-family: 'Poppins', sans-serif;
        ${tw`text-neutral-100`};
        background: #080b10;
        letter-spacing: 0.015em;
    }

    h1, h2, h3, h4, h5, h6 {
        font-family: 'Poppins', sans-serif;
        ${tw`font-medium tracking-normal`};
    }

    p {
        ${tw`text-neutral-200 leading-snug`};
    }

    form {
        ${tw`m-0`};
    }

    textarea,
    select,
    input,
    button,
    button:focus,
    button:focus-visible {
        ${tw`outline-none`};
    }

    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none !important;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield !important;
    }

    ::selection {
        background: rgba(34, 211, 238, 0.25);
    }

    ::-webkit-scrollbar {
        background: transparent;
        width: 10px;
        height: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: #252b35;
        border-radius: 6px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: #343c49;
    }

    ::-webkit-scrollbar-track {
        background: transparent;
    }

    ::-webkit-scrollbar-corner {
        background: transparent;
    }


    /* =========================================================
       PteroX V2
       ========================================================= */

    body.pterox-shell {
        background: #111525;
        color: #f4f6fa;
        padding-top: 48px;
        padding-left: 190px;
        min-height: 100vh;
        transition: padding-left 150ms ease;
    }

    .pterox-header {
        position: fixed;
        z-index: 100;
        top: 0;
        left: 0;
        right: 0;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #171d27;
        border-bottom: 1px solid #252d38;
        padding: 0 10px;
    }

    .pterox-header-left,
    .pterox-header-tools {
        display: flex;
        align-items: center;
        height: 100%;
    }

    .pterox-icon-button,
    .pterox-header-button,
    .pterox-tool-button {
        border: 0;
        background: transparent;
        color: #d7dde5;
        cursor: pointer;
        height: 38px;
        min-width: 38px;
        border-radius: 5px;
        transition: all 150ms ease;
    }

    .pterox-icon-button:hover,
    .pterox-header-button:hover,
    .pterox-tool-button:hover {
        background: #252d38;
        color: #fff;
    }

    .pterox-brand {
        margin-left: 12px;
        font-size: 28px;
        line-height: 1;
        font-weight: 700;
        color: #f5f7fa;
        text-decoration: none;
        letter-spacing: -1px;
    }

    .pterox-brand strong {
        color: #23aeea;
        font-weight: 800;
    }

    .pterox-header-tools {
        gap: 8px;
    }

    .pterox-tool-group {
        display: flex;
        align-items: center;
        background: #444950;
        border-radius: 8px;
        padding: 2px;
        margin-right: 10px;
    }

    .pterox-tool-button {
        width: 36px;
        min-width: 36px;
    }

    .pterox-orange-button {
        border: 0;
        border-radius: 4px;
        height: 34px;
        width: 48px;
        background: #ff5108;
        color: white;
        cursor: pointer;
        transition: filter 150ms ease;
    }

    .pterox-orange-button:hover {
        filter: brightness(1.12);
    }

    .pterox-sidebar {
        position: fixed;
        z-index: 90;
        left: 0;
        top: 48px;
        bottom: -1px;
        width: 190px !important;
        min-width: 190px !important;
        max-width: 190px !important;
        background: #19212c;
        border-right: 1px solid #242d39;
        display: flex;
        flex-direction: column;
        transition: transform 150ms ease;
    }

    /* Always-visible orange sidebar scroll indicator */
    .pterox-sidebar::after {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 4px;
        height: 42%;
        background: #ff5a16;
        border-radius: 2px;
        pointer-events: none;
        z-index: 5;
    }

    .pterox-sidebar-closed {
        transform: translateX(-100%);
    }

    .pterox-profile {
        display: flex;
        align-items: center;
        padding: 16px 14px 20px;
    }

    .pterox-x-logo {
        width: 40px;
        font-size: 49px;
        line-height: 45px;
        font-weight: 800;
        font-style: italic;
        color: #27b7f0;
        margin-right: 7px;
    }

    .pterox-profile-text {
        display: flex;
        flex-direction: column;
        min-width: 0;
    }

    .pterox-profile-text strong {
        font-size: 12px;
        line-height: 14px;
        color: #f5f5f5;
    }

    .pterox-profile-text span {
        font-size: 9px;
        line-height: 11px;
        color: #d0d6de;
        white-space: nowrap;
    }

    .pterox-sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0;
    }

    .pterox-sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        min-height: 46px;
        height: 46px;
        padding: 0 18px;
        border: 0;
        background: transparent;
        color: #e1e5ea;
        text-decoration: none;
        font-size: 12.5px;
        font-weight: 500;
        line-height: 1;
        text-align: left;
        cursor: pointer;
        transition: color 150ms ease, background 150ms ease;
        box-sizing: border-box;
    }

    .pterox-sidebar-link svg {
        width: 15px;
        min-width: 15px;
        height: 15px;
        flex-shrink: 0;
    }

    .pterox-sidebar-link:hover {
        color: #fff;
        background: transparent;
    }

    .pterox-sidebar-link-active {
        color: #ff5a16 !important;
    }

    .pterox-sidebar-section-title {
        margin-top: 24px;
        padding: 0 10px 18px;
        color: #ff5a16;
        font-size: 11px;
        line-height: 1.2;
        font-weight: 700;
        letter-spacing: 0.35px;
    }

    .pterox-server-link {
        min-height: 36px;
        height: 36px;
    }

    .pterox-sidebar-bottom {
        margin-top: 8px;
        padding-bottom: 12px;
    }

    .pterox-dashboard-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin: 26px 28px 28px;
    }

    .pterox-dashboard-header h1 {
        margin: 0;
        font-size: 25px;
        font-weight: 700;
        color: #f4f6fa;
    }

    .pterox-show-servers {
        border: 0;
        border-radius: 3px;
        background: #ff5108;
        color: #fff;
        padding: 11px 18px;
        font-size: 11px;
        font-weight: 700;
        cursor: pointer;
        text-transform: none;
    }

    .pterox-server-grid {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        flex-wrap: wrap;
        gap: 24px;
        padding: 18px 28px 40px;
    }

    .pterox-server-card {
        width: 348px;
        background: #1a222d;
        border: 2px solid #14a993;
        border-radius: 6px;
        overflow: hidden;
        box-shadow: 0 8px 25px rgba(0, 0, 0, .18);
    }

    .pterox-server-banner {
        position: relative;
        display: flex;
        height: 106px;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        overflow: hidden;
        background-image: url('/images/server-banner.jpg');
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
    }

    .pterox-server-banner-overlay {
        position: absolute;
        inset: 0;
        background: linear-gradient(
            180deg,
            rgba(0,0,0,.05),
            rgba(0,0,0,.48)
        );
    }

    .pterox-server-title {
        position: relative;
        z-index: 2;
        color: #fff;
        font-size: 27px;
        font-weight: 800;
        text-shadow: 0 2px 5px rgba(0,0,0,.75);
    }

    .pterox-server-info {
        display: grid;
        grid-template-columns: 1fr 1fr;
        padding: 10px 11px 7px;
        gap: 3px 18px;
        color: #f0f2f5;
        font-size: 11px;
        font-weight: 600;
    }

    .pterox-server-info > div {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }

    .pterox-server-info span {
        display: flex;
        align-items: center;
        gap: 7px;
        white-space: nowrap;
        min-height: 14px;
    }

    .pterox-server-info svg {
        width: 12px;
        color: #e7edf3;
        flex-shrink: 0;
    }

    .pterox-server-info .pterox-online {
        color: #2bd17e;
        font-size: 8px;
    }

    .pterox-server-actions {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        padding: 8px;
    }

    .pterox-server-actions a {
        height: 31px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        background: #ff5108;
        border-radius: 3px;
        text-decoration: none;
        transition: filter 150ms ease, transform 150ms ease;
    }

    .pterox-server-actions a:hover {
        filter: brightness(1.1);
        transform: translateY(-1px);
    }

    .pterox-empty {
        text-align: center;
        color: #697b8d;
        font-size: 13px;
        padding: 35px;
    }


    .pterox-console-page {
        position: relative;
        width: 100%;
        box-sizing: border-box;
        padding: 30px;
    }

    .pterox-console-page::before {
        content: '';
        position: absolute;
        left: -4px;
        top: 0;
        bottom: 0;
        width: 4px;
        background: #ff5108;
        pointer-events: none;
    }

    .pterox-server-header {
        min-height: 94px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        padding: 20px 22px;
        margin-bottom: 10px;
        background: #19212c;
        border: 1px solid #3b4656;
        border-radius: 3px;
        box-sizing: border-box;
    }

    .pterox-server-title {
        display: flex;
        align-items: center;
        gap: 9px;
        font-size: 24px;
        line-height: 1;
        font-weight: 700;
        color: #f4f6fa;
    }

    .pterox-server-header-info {
        display: flex;
        flex-direction: column;
        gap: 7px;
        min-width: 0;
    }

    .pterox-server-meta {
        display: flex;
        align-items: center;
        gap: 10px;
        color: #c7ced8;
        font-size: 11px;
        font-weight: 600;
        white-space: nowrap;
    }

    .pterox-server-meta-separator {
        color: #697687;
        font-size: 13px;
    }

    .pterox-server-status-dot {
        width: 13px;
        height: 13px;
        border-radius: 50%;
        background: #d83d4b;
        box-shadow: 0 0 0 2px rgba(216,61,75,.15);
    }

    .pterox-power-buttons {
        display: flex;
        gap: 7px;
        flex-wrap: nowrap;
    }

    .pterox-power-buttons button {
        min-width: 74px;
        height: 34px;
        border-radius: 4px !important;
        border: 0 !important;
        font-size: 12px !important;
        font-weight: 700 !important;
    }

    button.pterox-power-start {
        background: #2563b8 !important;
        color: #fff !important;
    }

    button.pterox-power-restart {
        background: #f59e0b !important;
        color: #fff !important;
    }

    button.pterox-power-stop {
        background: #ec4b86 !important;
        color: #fff !important;
    }

    .pterox-stat-grid {
        display: grid;
        grid-template-columns: repeat(6, minmax(0, 1fr));
        gap: 10px;
        margin-bottom: 14px;
    }

    .pterox-stat-card {
        min-width: 0;
        overflow: hidden;
        background: #19212c;
        border-radius: 3px;
    }

    .pterox-stat-card-head {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 31px;
        padding: 0 10px;
        background: #ff5108;
        color: #fff;
        font-size: 11px;
        font-weight: 800;
        letter-spacing: .3px;
    }

    .pterox-stat-card-head svg {
        width: 13px;
        min-width: 13px;
    }

    .pterox-status-icon {
        color: #ef4450;
    }

    .pterox-stat-card-value {
        min-height: 43px;
        display: flex;
        align-items: center;
        padding: 0 10px;
        background: #17202a;
        color: #f2f4f7;
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .pterox-stat-extra,
    .pterox-stat-limit {
        color: #cbd2da;
        font-weight: 500;
        font-size: 10px;
    }

    .pterox-console-panel {
        width: 100%;
        height: 490px;
        margin-bottom: 14px;
        overflow: hidden;
        background: #10181f;
        border: 1px solid #394452;
        border-radius: 3px;
        box-sizing: border-box;
    }

    .pterox-graphs-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
    }

    .pterox-graphs-grid > * {
        min-width: 0;
    }

    @media (max-width: 800px) {
        body.pterox-shell {
            padding-left: 0;
        }

        .pterox-sidebar {
            box-shadow: 8px 0 30px rgba(0,0,0,.35);
        }

        .pterox-dashboard-header {
            margin-left: 18px;
            margin-right: 18px;
        }


        .pterox-console-page {
            padding: 18px;
        }

        .pterox-console-panel {
            height: 400px;
        }

        .pterox-server-header {
            align-items: flex-start;
            flex-direction: column;
        }

        .pterox-power-buttons {
            width: 100%;
        }

        .pterox-power-buttons button {
            flex: 1;
        }

        .pterox-stat-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }

        .pterox-graphs-grid {
            grid-template-columns: 1fr;
        }

        .pterox-server-grid {
            padding-left: 12px;
            padding-right: 12px;
        }
    }



    /* PteroX File Manager page layout */

    .pterox-file-content {
        width: calc(100% - 80px) !important;
        max-width: none !important;
        margin-left: 40px !important;
        margin-right: 40px !important;
        box-sizing: border-box;
    }

    .pterox-file-page {
        width: 100%;
        max-width: none;
        min-width: 0;
        box-sizing: border-box;
    }

    .pterox-file-title {
        margin: 14px 0 10px;
        padding: 0;
        font-size: 27px;
        line-height: 1.2;
        font-weight: 700;
        color: #f4f6fa;
    }

    @media (max-width: 800px) {
        .pterox-file-content {
            width: calc(100% - 36px) !important;
            margin-left: 18px !important;
            margin-right: 18px !important;
        }
    }


    /* PteroX mass file actions */

    .pterox-mass-action {
        background: #ff5108 !important;
        border-color: #ff5108 !important;
        color: #ffffff !important;
    }

    .pterox-mass-action:hover {
        background: #ff641f !important;
        border-color: #ff641f !important;
    }

    .pterox-mass-action-danger {
        background: transparent !important;
        border-color: transparent !important;
        color: #ff5108 !important;
    }

    .pterox-mass-action-danger:hover {
        background: rgba(255, 81, 8, 0.12) !important;
        border-color: transparent !important;
        color: #ff641f !important;
    }



    /* =========================================================
       PteroX initial loading screen
       ========================================================= */

    .pterox-loading-screen {
        position: fixed;
        inset: 0;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #0f141b;
    }


    /* =========================================================
       PteroX schedule modal form
       ========================================================= */

    .pterox-schedule-modal {
        color: #f4f6fa;
    }

    .pterox-schedule-modal h3 {
        color: #ffffff !important;
        font-weight: 700;
    }

    .pterox-schedule-modal label {
        color: #e5e7eb !important;
    }

    .pterox-schedule-modal input {
        background: #111923 !important;
        border-color: #263241 !important;
        color: #ffffff !important;
    }

    .pterox-schedule-modal input:focus {
        border-color: #ff5108 !important;
        box-shadow: 0 0 0 1px #ff5108 !important;
    }

    .pterox-schedule-modal input::placeholder {
        color: #64748b !important;
    }

    .pterox-schedule-modal .text-neutral-400 {
        color: #94a3b8 !important;
    }

    .pterox-schedule-modal > div {
        background: #273443 !important;
        border-color: #344454 !important;
    }


    .pterox-schedule-option {
        background: #1c2733 !important;
        border: 1px solid #2d3b49 !important;
    }

    .pterox-schedule-option p {
        color: #94a3b8 !important;
    }

    .pterox-schedule-modal button {
        transition: background 120ms ease, border-color 120ms ease;
    }

    .pterox-schedule-modal button:hover {
        filter: brightness(1.05);
    }

    .pterox-schedule-modal .pterox-button {
        background: #ff5108 !important;
        color: #ffffff !important;
    }

    .pterox-schedule-modal .pterox-button:hover {
        background: #ff641f !important;
    }



    /* =========================================================
       PteroX initial page loader
       ========================================================= */

    #pterox-preloader {
        position: fixed;
        inset: 0;
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #0f141b;
        opacity: 1;
        visibility: visible;
        transition: opacity 180ms ease, visibility 180ms ease;
    }

    #pterox-preloader.pterox-loaded {
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }

    .pterox-preloader-spinner {
        width: 46px;
        height: 46px;
        border: 5px solid rgba(255, 81, 8, 0.22);
        border-top-color: #ff5108;
        border-radius: 50%;
        animation: pterox-preloader-spin 0.8s linear infinite;
    }

    @keyframes pterox-preloader-spin {
        to {
            transform: rotate(360deg);
        }
    }



`;


import { PTEROX_CONFIG } from '@/pterox.config';
import React, { forwardRef } from 'react';
import { Form } from 'formik';
import styled from 'styled-components/macro';
import FlashMessageRender from '@/components/FlashMessageRender';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const AuthShell = styled.div`
    min-height: 100vh;
    width: 100%;
    background: #0f1424;
    color: #f1f5f9;
`;

const AuthHeader = styled.header`
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 26px;
    background: #171f2a;
    border-bottom: 1px solid #273447;
    box-sizing: border-box;
`;

const Brand = styled.div`
    font-family: 'Poppins', sans-serif;
    font-size: 27px;
    font-weight: 700;
    letter-spacing: -1px;

    span {
        color: #f1f5f9;
    }

    strong {
        color: #19aeea;
    }
`;

const HeaderAction = styled.div`
    width: 40px;
    height: 40px;
    border-radius: 6px;
    background: #ff5500;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ffffff;
    font-size: 17px;
    font-weight: 700;
`;

const AuthMain = styled.main`
    width: 100%;
    max-width: 1120px;
    margin: 0 auto;
    padding: 52px 32px 30px;
    box-sizing: border-box;
`;

const AuthLayout = styled.div`
    display: flex;
    align-items: flex-start;
    gap: 70px;

    @media (max-width: 800px) {
        flex-direction: column;
        align-items: center;
        gap: 35px;
    }
`;

const LoginColumn = styled.div`
    width: 420px;
    flex: 0 0 420px;

    @media (max-width: 800px) {
        width: 100%;
        max-width: 420px;
        flex: none;
    }
`;

const AuthTitle = styled.h2`
    margin: 0 0 18px;
    color: #f8fafc;
    font-family: 'Poppins', sans-serif;
    font-size: 34px;
    font-weight: 500;
    line-height: 1.2;
`;

const LoginCard = styled.div`
    width: 100%;
    box-sizing: border-box;
    padding: 22px;
    background: #171f2a;
    border: 1px solid #29384b;
    border-radius: 6px;
    box-shadow: 0 18px 45px rgba(0, 0, 0, 0.25);
`;

const LogoSide = styled.div`
    flex: 1;
    min-height: 385px;
    display: flex;
    align-items: center;
    justify-content: center;

    img {
        width: 190px;
        height: 190px;
        object-fit: contain;
        filter: drop-shadow(0 0 22px rgba(25, 174, 234, 0.18));
    }

    @media (max-width: 800px) {
        min-height: 180px;

        img {
            width: 150px;
            height: 150px;
        }
    }
`;

const Footer = styled.p`
    margin: 22px 0 0;
    text-align: center;
    color: #64748b;
    font-family: 'Poppins', sans-serif;
    font-size: 12px;
`;

export default forwardRef<HTMLFormElement, Props>(({ title, children, ...props }, ref) => (
    <AuthShell>
        <AuthHeader>
            <Brand>
                <span>{PTEROX_CONFIG.headerName.slice(0, -1)}</span>
                <strong>{PTEROX_CONFIG.headerName.slice(-1)}</strong>
            </Brand>

            <HeaderAction>↗</HeaderAction>
        </AuthHeader>

        <AuthMain>
            <AuthLayout>
                <LoginColumn>
                    <Form {...props} ref={ref}>
                        <LoginCard>
                            {title && <AuthTitle>{title}</AuthTitle>}

                            <div>
                                {children}
                            </div>

                            <FlashMessageRender className={'mt-6'} />
                        </LoginCard>
                    </Form>
                </LoginColumn>

                <LogoSide>
                    <img src={PTEROX_CONFIG.logo} alt={`${PTEROX_CONFIG.name} logo`} />
                </LogoSide>
            </AuthLayout>

            <Footer>{PTEROX_CONFIG.headerName} © {new Date().getFullYear()}</Footer>
        </AuthMain>
    </AuthShell>
));

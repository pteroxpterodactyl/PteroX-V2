import { PTEROX_CONFIG } from '../pterox.config';
import * as React from 'react';
import { useEffect, useState } from 'react';
import { Link, NavLink, useRouteMatch } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faBars,
    faSearch,
    faLayerGroup,
    faServer,
    faBook,
    faCreditCard,
    faUser,
    faLanguage,
    faFileAlt,
    faRocket,
    faTerminal,
    faFolderOpen,
    faDatabase,
    faCalendarAlt,
    faUsers,
    faArchive,
    faGlobe,
    faPlayCircle,
    faCog,
    faEye,
} from '@fortawesome/free-solid-svg-icons';
import { faDiscord } from '@fortawesome/free-brands-svg-icons';
import {
    ArchiveIcon,
    CalendarIcon,
    CogIcon,
    CreditCardIcon,
    DocumentTextIcon,
    FolderIcon,
    GlobeAltIcon,
    InformationCircleIcon,
    LogoutIcon,
    PlayIcon,
    ServerIcon,
    TerminalIcon,
    UserGroupIcon,
    UserIcon,
} from '@heroicons/react/outline';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Avatar from '@/components/Avatar';
import Can from '@/components/elements/Can';
import routes from '@/routers/routes';

const SidebarLink = ({
    to,
    icon,
    children,
    exact = false,
}: {
    to: string;
    icon: any;
    children: React.ReactNode;
    exact?: boolean;
}) => (
    <NavLink
        to={to}
        exact={exact}
        className={'pterox-sidebar-link'}
        activeClassName={'pterox-sidebar-link-active'}
    >
        {React.createElement(icon, { className: 'w-5 h-5' })}
        <span>{children}</span>
    </NavLink>
);

const getServerRouteIcon = (name: string) => {
    switch (name.toLowerCase()) {
        case 'console':
            return TerminalIcon;
        case 'files':
            return FolderIcon;
        case 'databases':
            return ServerIcon;
        case 'schedules':
            return CalendarIcon;
        case 'users':
        case 'subusers':
            return UserGroupIcon;
        case 'backups':
            return ArchiveIcon;
        case 'network':
            return GlobeAltIcon;
        case 'startup':
            return PlayIcon;
        case 'settings':
            return CogIcon;
        case 'activity':
            return InformationCircleIcon;
        default:
            return ServerIcon;
    }
};

export default () => {
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
    const [isLoggingOut, setIsLoggingOut] = useState(false);
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const serverMatch = useRouteMatch<{ id: string }>('/server/:id');

    useEffect(() => {
        document.body.classList.add('pterox-shell');

        return () => {
            document.body.classList.remove('pterox-shell');
        };
    }, []);

    const onTriggerLogout = () => {
        setIsLoggingOut(true);

        http.post('/auth/logout').finally(() => {
            // @ts-expect-error valid browser navigation
            window.location = '/';
        });
    };

    return (
        <>
            <SpinnerOverlay visible={isLoggingOut} />

            <header className={'pterox-header'}>
                <div className={'pterox-header-left'}>
                    <button
                        className={'pterox-icon-button'}
                        onClick={() => setSidebarOpen((value) => !value)}
                        aria-label={'Toggle sidebar'}
                    >
                        <FontAwesomeIcon icon={faBars} />
                    </button>

                    <Link to={'/'} className={'pterox-brand'}>
                        <span>{PTEROX_CONFIG.headerName.slice(0, -1)}</span>
                        <strong>{PTEROX_CONFIG.headerName.slice(-1)}</strong>
                    </Link>
                </div>

                <div className={'pterox-header-tools'}>
                    <div className={'pterox-tool-group'}>
                        <button className={'pterox-tool-button'} title={'Tools'}>
                            <FontAwesomeIcon icon={faLanguage} />
                        </button>
                        <button className={'pterox-tool-button'} title={'Documents'}>
                            <FontAwesomeIcon icon={faFileAlt} />
                        </button>
                        <button className={'pterox-tool-button'} title={'Language'}>
                            <FontAwesomeIcon icon={faLanguage} />
                        </button>
                    </div>

                    <button className={'pterox-header-button'} title={'Search'}>
                        <FontAwesomeIcon icon={faSearch} />
                    </button>

                    <button className={'pterox-orange-button'} title={'PteroX'}>
                        <FontAwesomeIcon icon={faRocket} />
                    </button>
                </div>
            </header>

            <aside className={`pterox-sidebar ${sidebarOpen ? '' : 'pterox-sidebar-closed'}`}>
                <div className={'pterox-profile'}>
                    <div className={'pterox-x-logo'}>
                        <img
                            src={PTEROX_CONFIG.logo}
                            alt={`${PTEROX_CONFIG.name} logo`}
                        />
                    </div>

                    <div className={'pterox-profile-text'}>
                        <strong>{PTEROX_CONFIG.name}</strong>
                        <span>{PTEROX_CONFIG.email}</span>
                    </div>
                </div>

                <nav className={'pterox-sidebar-nav'}>
                    <SidebarLink to={'/'} icon={ServerIcon} exact>
                        My Servers
                    </SidebarLink>

                    {!serverMatch && (
                        <>
                            <SidebarLink to={'/knowledge'} icon={InformationCircleIcon}>
                                Knowledge Base
                            </SidebarLink>

                            <a
                                href={'https://discord.com'}
                                target={'_blank'}
                                rel={'noreferrer'}
                                className={'pterox-sidebar-link'}
                            >
                                <FontAwesomeIcon icon={faDiscord} />
                                <span>Discord</span>
                            </a>

                            <a href={'/billing'} className={'pterox-sidebar-link'}>
                                <CreditCardIcon className={'w-5 h-5'} />
                                <span>Billing</span>
                            </a>

                            <SidebarLink to={'/account'} icon={UserIcon}>
                                My Account
                            </SidebarLink>
                        </>
                    )}

                    {serverMatch && (
                        <>
                            <div className={'pterox-sidebar-section-title'}>
                                SERVER MANAGEMENT
                            </div>

                            {routes.server
                                .filter((route) => !!route.name)
                                .map((route) => {
                                    const target =
                                        route.path === '/'
                                            ? serverMatch.url
                                            : `${serverMatch.url}${route.path}`;

                                    const link = (
                                        <NavLink
                                            key={route.path}
                                            to={target}
                                            exact={route.exact}
                                            className={'pterox-sidebar-link pterox-server-link'}
                                            activeClassName={'pterox-sidebar-link-active'}
                                        >
                                            {React.createElement(getServerRouteIcon(route.name!), { className: 'w-5 h-5' })}
                                            <span>{route.name === 'Users' ? 'Subusers' : route.name === 'Activity' ? 'Logs' : route.name}</span>
                                        </NavLink>
                                    );

                                    return route.permission ? (
                                        <Can
                                            key={route.path}
                                            action={route.permission}
                                            matchAny
                                        >
                                            {link}
                                        </Can>
                                    ) : (
                                        link
                                    );
                                })}
                        </>
                    )}
                </nav>

                <div className={'pterox-sidebar-bottom'}>
                    {serverMatch && (
                        <div className={'pterox-sidebar-section-title'}>
                            ACCOUNT MANAGEMENT
                        </div>
                    )}

                    {rootAdmin && (
                        <a href={'/admin'} className={'pterox-sidebar-link'}>
                            <CogIcon className={'w-5 h-5'} />
                            <span>Admin Panel</span>
                        </a>
                    )}

                    <button onClick={onTriggerLogout} className={'pterox-sidebar-link'}>
                        <LogoutIcon className={'w-5 h-5'} />
                        <span>Logout</span>
                    </button>
                </div>
            </aside>
        </>
    );
};

import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';

const SubNavigation = styled.div`
    ${tw`w-full shadow overflow-x-auto`};
    background: #151d27;
    border-bottom: 1px solid #263341;

    & > div {
        ${tw`flex items-center text-sm mx-auto px-2`};
        max-width: 1200px;

        & > a,
        & > div {
            display: inline-block;
            padding: 0.8rem 1rem;
            color: #94a3b8;
            text-decoration: none;
            white-space: nowrap;
            transition: all 150ms ease;

            &:not(:first-of-type) {
                ${tw`ml-2`};
            }

            &:hover {
                color: #ffffff;
            }

            &:active,
            &.active {
                color: #ffffff;
                box-shadow: inset 0 -2px #ff5500;
            }
        }
    }
`;

export default SubNavigation;

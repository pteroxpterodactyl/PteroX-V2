import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex items-center p-4 overflow-hidden no-underline text-neutral-200 transition-all duration-150`};

    background: #10151d;
    border: 1px solid #1d2530;
    border-radius: 10px;

    ${(props) =>
        props.$hoverable !== false &&
        `
            &:hover {
                background: #131a23;
                border-color: #303b4a;
                transform: translateY(-1px);
            }
        `};

    & .icon {
        ${tw`flex items-center justify-center p-3`};

        width: 48px;
        height: 48px;
        border-radius: 10px;
        background: #18212c;
        color: #67e8f9;
    }
`;

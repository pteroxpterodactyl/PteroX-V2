import React, { memo } from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import StatGraphs from '@/components/server/console/StatGraphs';
import PowerButtons from '@/components/server/console/PowerButtons';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import { Alert } from '@/components/elements/alert';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const ServerConsoleContainer = () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const allocation = ServerContext.useStoreState((state) => state.server.data!.allocations[0]);
    const identifier = ServerContext.useStoreState((state) => state.server.data!.identifier);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);

    return (
        <div className={'pterox-console-page'}>
            {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                <Alert type={'warning'} className={'mb-4'}>
                    {isNodeUnderMaintenance
                        ? 'The node of this server is currently under maintenance and all actions are unavailable.'
                        : isInstalling
                        ? 'This server is currently running its installation process and most actions are unavailable.'
                        : 'This server is currently being transferred to another node and all actions are unavailable.'}
                </Alert>
            )}

            <div className={'pterox-server-header'}>
                <div className={'pterox-server-header-info'}>
                    <div className={'pterox-server-title'}>
                        {name}
                        <span className={'pterox-server-status-dot'} />
                    </div>

                    <div className={'pterox-server-meta'}>
                        <span>
                            {allocation?.alias || allocation?.ip}:{allocation?.port}
                        </span>
                        <span className={'pterox-server-meta-separator'}>•</span>
                        <span>{identifier}</span>
                    </div>
                </div>

                <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                    <PowerButtons className={'pterox-power-buttons'} />
                </Can>
            </div>

            <ServerDetailsBlock />

            <div className={'pterox-console-panel'}>
                <Spinner.Suspense>
                    <Console />
                </Spinner.Suspense>
            </div>

            <div className={'pterox-graphs-grid'}>
                <Spinner.Suspense>
                    <StatGraphs />
                </Spinner.Suspense>
            </div>

            <Features enabled={eggFeatures} />
        </div>
    );
};

export default memo(ServerConsoleContainer, isEqual);

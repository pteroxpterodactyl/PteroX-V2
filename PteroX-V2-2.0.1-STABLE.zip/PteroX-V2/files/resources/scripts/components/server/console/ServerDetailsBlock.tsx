import React, { useEffect, useMemo, useState } from 'react';
import {
    faCircle,
    faHdd,
    faKey,
    faMemory,
    faMicrochip,
    faWifi,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import UptimeDuration from '@/components/server/UptimeDuration';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { capitalize } from '@/lib/strings';

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

const ServerDetailsBlock = () => {
    const [stats, setStats] = useState<Stats>({
        memory: 0,
        cpu: 0,
        disk: 0,
        uptime: 0,
        tx: 0,
        rx: 0,
    });

    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);

    const textLimits = useMemo(
        () => ({
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    useEffect(() => {
        if (!connected || !instance) return;

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let values: any = {};

        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            memory: values.memory_bytes,
            cpu: values.cpu_absolute,
            disk: values.disk_bytes,
            tx: values.network.tx_bytes,
            rx: values.network.rx_bytes,
            uptime: values.uptime || 0,
        });
    });

    const statusText = status === null ? 'Offline' : capitalize(status);
    const supportId = uuid ? uuid.slice(0, 8) : '--------';

    return (
        <div className={'pterox-stat-grid'}>
            <div className={'pterox-stat-card'}>
                <div className={'pterox-stat-card-head'}>
                    <FontAwesomeIcon icon={faCircle} className={'pterox-status-icon'} />
                    <span>STATUS</span>
                </div>

                <div className={'pterox-stat-card-value'}>
                    {statusText}

                    {stats.uptime > 0 && (
                        <span className={'pterox-stat-extra'}>
                            {' '}
                            <UptimeDuration uptime={stats.uptime / 1000} />
                        </span>
                    )}
                </div>
            </div>

            <div className={'pterox-stat-card'}>
                <div className={'pterox-stat-card-head'}>
                    <FontAwesomeIcon icon={faWifi} />
                    <span>IP ADDRESS</span>
                </div>

                <div className={'pterox-stat-card-value'}>
                    {allocation}
                </div>
            </div>

            <div className={'pterox-stat-card'}>
                <div className={'pterox-stat-card-head'}>
                    <FontAwesomeIcon icon={faKey} />
                    <span>SUPPORT ID</span>
                </div>

                <div className={'pterox-stat-card-value'}>
                    {supportId}
                </div>
            </div>

            <div className={'pterox-stat-card'}>
                <div className={'pterox-stat-card-head'}>
                    <FontAwesomeIcon icon={faMicrochip} />
                    <span>CPU</span>
                </div>

                <div className={'pterox-stat-card-value'}>
                    {status === 'offline' ? 'Offline' : `${stats.cpu.toFixed(2)}%`}
                    <span className={'pterox-stat-limit'}>
                        {' / '}
                        {limits?.cpu ? `${limits.cpu}%` : '∞'}
                    </span>
                </div>
            </div>

            <div className={'pterox-stat-card'}>
                <div className={'pterox-stat-card-head'}>
                    <FontAwesomeIcon icon={faMemory} />
                    <span>RAM</span>
                </div>

                <div className={'pterox-stat-card-value'}>
                    {status === 'offline' ? 'Offline' : bytesToString(stats.memory)}
                    <span className={'pterox-stat-limit'}>
                        {' / '}
                        {textLimits.memory || '∞'}
                    </span>
                </div>
            </div>

            <div className={'pterox-stat-card'}>
                <div className={'pterox-stat-card-head'}>
                    <FontAwesomeIcon icon={faHdd} />
                    <span>STORAGE</span>
                </div>

                <div className={'pterox-stat-card-value'}>
                    {bytesToString(stats.disk)}
                    <span className={'pterox-stat-limit'}>
                        {' / '}
                        {textLimits.disk || '∞'}
                    </span>
                </div>
            </div>
        </div>
    );
};

export default ServerDetailsBlock;

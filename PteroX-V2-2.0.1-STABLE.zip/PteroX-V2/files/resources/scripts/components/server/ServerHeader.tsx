import React from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import PowerButtons from '@/components/server/console/PowerButtons';

const ServerHeader = () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const allocation = ServerContext.useStoreState((state) => state.server.data!.allocations[0]);
    const identifier = ServerContext.useStoreState((state) => state.server.data!.identifier);

    return (
        <div className={'pterox-server-header'}>
            <div className={'pterox-server-header-info'}>
                <div className={'pterox-server-title'}>
                    {name}
                    <span className={'pterox-server-status-dot'} />
                </div>

                <div className={'pterox-server-meta'}>
                    <span>
                        {allocation?.alias || allocation?.ip}:{allocation?.port}
                    </span>
                    <span className={'pterox-server-meta-separator'}>•</span>
                    <span>{identifier}</span>
                </div>
            </div>

            <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                <PowerButtons className={'pterox-power-buttons'} />
            </Can>
        </div>
    );
};

export default ServerHeader;

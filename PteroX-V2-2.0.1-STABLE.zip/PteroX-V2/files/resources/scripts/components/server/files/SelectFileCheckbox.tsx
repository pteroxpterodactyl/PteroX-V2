import React from 'react';
import tw from 'twin.macro';
import { ServerContext } from '@/state/server';
import styled from 'styled-components/macro';
import Input from '@/components/elements/Input';

export const FileActionCheckbox = styled(Input)`
    && {
        ${tw`border-neutral-500 bg-transparent`};

        width: 16px;
        height: 16px;
        min-width: 16px;
        min-height: 16px;
        margin: 0;
        accent-color: #ff5108;

        &:checked {
            accent-color: #ff5108;
            background-color: #ff5108;
            border-color: #ff5108;
        }

        &:not(:checked) {
            border-color: #ff5108;
            background-color: transparent;
            ${tw`hover:border-neutral-300`};
        }
    }
`;

export default ({ name }: { name: string }) => {
    const isChecked = ServerContext.useStoreState(
        (state) => state.files.selectedFiles.indexOf(name) >= 0
    );

    const appendSelectedFile = ServerContext.useStoreActions(
        (actions) => actions.files.appendSelectedFile
    );

    const removeSelectedFile = ServerContext.useStoreActions(
        (actions) => actions.files.removeSelectedFile
    );

    return (
        <label
            css={tw`
                flex-none
                flex
                items-center
                justify-center
                w-10
                h-full
                cursor-pointer
                z-30
            `}
        >
            <FileActionCheckbox
                name={'selectedFiles'}
                value={name}
                checked={isChecked}
                type={'checkbox'}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    if (e.currentTarget.checked) {
                        appendSelectedFile(name);
                    } else {
                        removeSelectedFile(name);
                    }
                }}
            />
        </label>
    );
};

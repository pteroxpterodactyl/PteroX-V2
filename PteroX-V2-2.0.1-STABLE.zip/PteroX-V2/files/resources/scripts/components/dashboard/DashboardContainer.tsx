import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import useSWR from 'swr';

export default () => {
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(
        !isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1
    );

    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);

    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(
        `${uuid}:show_all_servers`,
        false
    );

    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({
            page,
            type: showOnlyAdmin && rootAdmin ? 'admin' : undefined,
        })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;

        if (
            servers.pagination.currentPage > 1 &&
            !servers.items.length
        ) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        window.history.replaceState(
            null,
            document.title,
            `/${page <= 1 ? '' : `?page=${page}`}`
        );
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    return (
        <PageContentBlock title={'Your servers'} showFlashKey={'dashboard'}>
            <div className={'pterox-dashboard-header'}>
                <h1>Your servers</h1>

                {rootAdmin && (
                    <button
                        className={'pterox-show-servers'}
                        onClick={() => setShowOnlyAdmin((value) => !value)}
                    >
                        {showOnlyAdmin
                            ? 'Showing all servers'
                            : 'Showing your servers'}
                    </button>
                )}
            </div>

            {!servers ? (
                <Spinner centered size={'large'} />
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items }) =>
                        items.length > 0 ? (
                            <div className={'pterox-server-grid'}>
                                {items.map((server) => (
                                    <ServerRow
                                        key={server.uuid}
                                        server={server}
                                    />
                                ))}
                            </div>
                        ) : (
                            <div className={'pterox-empty'}>
                                There are no servers associated with your account.
                            </div>
                        )
                    }
                </Pagination>
            )}
        </PageContentBlock>
    );
};

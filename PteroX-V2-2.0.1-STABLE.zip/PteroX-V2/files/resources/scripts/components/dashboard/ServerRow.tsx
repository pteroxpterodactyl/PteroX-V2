import React, { memo, useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faTerminal,
    faFolder,
    faDatabase,
    faCog,
    faMicrochip,
    faMemory,
    faHdd,
    faCircle,
} from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, {
    ServerPowerState,
    ServerStats,
} from '@/api/server/getServerResourceUsage';
import { bytesToString, mbToBytes } from '@/lib/formatters';
import Spinner from '@/components/elements/Spinner';

type Timer = ReturnType<typeof setInterval>;

export default memo(({ server, className }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        if (server.status === 'suspended' || server.isNodeUnderMaintenance) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [server.uuid, server.status, server.isNodeUnderMaintenance]);

    const cpu = stats ? stats.cpuUsagePercent.toFixed(2) : '0.00';
    const memory = stats ? bytesToString(stats.memoryUsageInBytes) : '0 B';
    const disk = stats ? bytesToString(stats.diskUsageInBytes) : '0 B';

    const memoryLimit =
        server.limits.memory !== 0
            ? bytesToString(mbToBytes(server.limits.memory))
            : 'Unlimited';

    const diskLimit =
        server.limits.disk !== 0
            ? bytesToString(mbToBytes(server.limits.disk))
            : 'Unlimited';

    const running = stats?.status === 'running';

    return (
        <div className={`pterox-server-card ${className || ''}`}>
            <Link to={`/server/${server.id}`} className={'pterox-server-banner'}>
                <div className={'pterox-server-banner-overlay'} />
                <div className={'pterox-server-title'}>
                    {server.name}
                </div>
            </Link>

            <div className={'pterox-server-info'}>
                <div>
                    <span>
                        <FontAwesomeIcon icon={faMemory} />
                        {memory}
                    </span>
                    <span>
                        <FontAwesomeIcon icon={faMicrochip} />
                        {cpu}%
                    </span>
                    <span>
                        <FontAwesomeIcon icon={faHdd} />
                        {disk}
                    </span>
                </div>

                <div>
                    <span>
                        <FontAwesomeIcon icon={faCircle} className={running ? 'pterox-online' : ''} />
                        {running ? 'Online' : 'Offline'}
                    </span>
                    <span>
                        <FontAwesomeIcon icon={faMemory} />
                        {memoryLimit}
                    </span>
                    <span>
                        <FontAwesomeIcon icon={faHdd} />
                        {diskLimit}
                    </span>
                </div>
            </div>

            <div className={'pterox-server-actions'}>
                <Link to={`/server/${server.id}`} title={'Console'}>
                    <FontAwesomeIcon icon={faTerminal} />
                </Link>

                <Link to={`/server/${server.id}/files`} title={'Files'}>
                    <FontAwesomeIcon icon={faFolder} />
                </Link>

                <Link to={`/server/${server.id}/databases`} title={'Databases'}>
                    <FontAwesomeIcon icon={faDatabase} />
                </Link>

                <Link to={`/server/${server.id}/settings`} title={'Settings'}>
                    <FontAwesomeIcon icon={faCog} />
                </Link>
            </div>
        </div>
    );
});

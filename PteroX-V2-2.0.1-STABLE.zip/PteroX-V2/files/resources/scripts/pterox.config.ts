/**
 * PteroX V2 Branding Configuration
 *
 * Customers can edit this file to customize their PteroX branding.
 */

export const PTEROX_CONFIG = {
    name: 'pterox',
    email: 'pterox@webpool.tech',

    // Sidebar logo
    logo: '/images/pterox-logo.webp',

    // Header / top-left branding
    headerName: 'PteroX',
};
